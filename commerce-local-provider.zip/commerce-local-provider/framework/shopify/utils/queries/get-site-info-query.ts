const getSiteInfoQuery = /* GraphQL */ `
  query getSiteInfo {
    shop {
      name
    }
  }
`
export default getSiteInfoQuery

import * as Core from '@commerce/types/customer'

export * from '@commerce/types/customer'

export type CustomerSchema = Core.CustomerSchema

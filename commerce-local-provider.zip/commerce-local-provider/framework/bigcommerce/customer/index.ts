export { default as useCustomer } from './use-customer'

export type WishlistItem = { product: any; id: number }
export default function () {}

export { default } from './WishlistButton'

export { default } from './WishlistCard'

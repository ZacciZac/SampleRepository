export { default } from './Text'

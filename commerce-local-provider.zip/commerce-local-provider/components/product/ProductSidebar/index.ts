export { default } from './ProductSidebar'

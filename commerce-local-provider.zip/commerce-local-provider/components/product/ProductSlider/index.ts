export { default } from './ProductSlider'

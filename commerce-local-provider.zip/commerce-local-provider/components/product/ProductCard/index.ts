export { default } from './ProductCard'

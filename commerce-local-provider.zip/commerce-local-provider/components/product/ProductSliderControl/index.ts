export { default } from './ProductSliderControl'

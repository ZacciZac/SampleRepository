export { default } from './ProductView'

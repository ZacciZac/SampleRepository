export { default } from './ProductTag'
